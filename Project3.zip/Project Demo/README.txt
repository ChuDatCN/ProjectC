mở terminal tại thư mục hiện tại
Cấp quyền chạy cho run.sh: chmod +x compile.sh
khởi chạy: ./run.sh
sử dụng tham số -r để dịch lại: ./run.sh -r
